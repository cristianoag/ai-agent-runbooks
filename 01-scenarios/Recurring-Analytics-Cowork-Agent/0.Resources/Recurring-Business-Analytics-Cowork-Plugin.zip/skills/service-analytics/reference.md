# Fabric IQ Service Analytics reference

## KPI dictionary by sub-report

### Cases
| KPI | Definition | Typical source field |
| --- | --- | --- |
| Cases opened | Count of new cases in period | `CasesOpened` measure |
| Cases closed | Count of cases resolved in period | `CasesClosed` measure |

### Backlog
| KPI | Definition | Typical source field |
| --- | --- | --- |
| Open backlog | Cases open at end of period | `OpenBacklog` measure |
| Backlog aging | Distribution of open cases by age bucket | Age-bucket dimension, if modeled |

### SLA
| KPI | Definition | Typical source field |
| --- | --- | --- |
| SLA compliance % | Cases resolved within SLA ÷ total resolved | `SLACompliance%` measure |
| SLA breach count | Cases resolved (or still open) past SLA target | `SLABreaches` measure |

## Materiality thresholds (defaults)

| Flag | Band |
| --- | --- |
| 🟢 Green | Change within ±5% |
| 🟡 Amber | Change between ±5% and ±15% |
| 🔴 Red | Change beyond ±15%, or any SLA breach regardless of magnitude |

Override with cohort-specific thresholds if configured in the report.

## Narrative style

- Always surface SLA breaches in the executive summary, even a single breach — SLA is a
  contractual/reputational signal, not just an operational metric.
- Report backlog aging distribution, not just a raw open-case count, when the report supports it.
