# Leader Comms reference

## Message patterns

| Pattern | Use when | Structure |
| --- | --- | --- |
| Status update | Reader needs concise progress | Point -> table -> interpretation -> next step |
| Decision request | Reader must decide | Ask -> options -> recommendation -> due date |
| Risk note | Reader needs awareness or support | Risk -> impact -> mitigation -> requested support |
| Delegation note | Work needs an owner | Context -> task -> owner -> due date -> success criteria |
| Stakeholder summary | Multiple signals need synthesis | Headline -> key changes -> implications -> action |

## Table design

Use the smallest table that clarifies the message.

| Column | Use for |
| --- | --- |
| Metric / Topic | The item being summarized |
| Current | Current value or state |
| Change | Delta, trend, or movement |
| Owner | Person or group accountable |
| Due | Date or milestone |
| Status | Green, Amber, Red, or textual state |
| Action Needed | Specific next step or decision |

Remove unused columns. If no table helps, say the message is clearer as narrative only.

## Executive writing rules

- Open with the action or decision.
- Keep context short and relevant.
- Use plain language.
- Quantify only when the source provides numbers.
- Close with owner, due date, or requested response.
- Preserve uncertainty instead of smoothing it over.

## Send gate

Before sending or posting:

1. Show recipients.
2. Show exact message text.
3. Show attachments or links.
4. Warn if the content contains private data from calendar, mail, Teams, files, or meetings.
5. Wait for explicit confirmation.

Default status: draft only.
