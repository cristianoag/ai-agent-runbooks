# Chief-of-staff

A coordinated leadership productivity skill package for weekly readiness, executive communication,
leadership packs, team visibility, and skill routing.

## Skills

| Skill | Purpose |
| --- | --- |
| `leader-360` | Monday-ready weekly operating brief with dashboard, leadership update, risks, and first moves |
| `leader-concierge` | Front door that routes the user's goal to the right Chief-of-staff skill |
| `team-pulse` | Weekly visible-work digest across direct reports, with blocker and low-visibility flags |
| `leader-comms` | Executive-ready emails, Teams updates, stakeholder notes, and compact data-backed summaries |
| `leadership-pack` | Board, steering committee, QBR, and leadership pack structure with governance tables |

## Folder standard

Each skill folder contains:

- `SKILL.md` - the executable skill definition, workflow, output format, and guardrails
- `reference.md` - supporting patterns, routing rules, examples, and quality standards

## Package standards

- Use a consistent leadership-ready format: At a glance, inputs, workflow, output template,
  style standard, guardrails, and reference.
- Keep outputs review-ready by default.
- Never send, post, publish, share, create tasks, update systems, or change calendars without
  explicit user confirmation.
- Ground claims in supplied or retrieved evidence.
- Show source gaps instead of hiding or filling them.
- Avoid unsupported claims, personal evaluation, surveillance, and unnecessary private details.

## Recommended cadence

`leader-360` is the default scheduled workflow: every Monday at 8:00 AM local time.

All other skills are on demand unless the user explicitly asks to make them recurring.
