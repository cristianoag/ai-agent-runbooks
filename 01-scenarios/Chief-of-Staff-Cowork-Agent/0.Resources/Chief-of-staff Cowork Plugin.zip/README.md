# Chief of Staff Cowork Plugin

This package is ready for Cowork plugin upload surfaces that expect a Microsoft 365 app manifest plus expanded agent skill folders.

## Contents

```text
manifest.json
color.png
outline.png
skills/
  leader-360/
    SKILL.md
    reference.md
  leader-concierge/
    SKILL.md
    reference.md
  executive-drafts/
    SKILL.md
    reference.md
  leadership-pack/
    SKILL.md
    reference.md
  team-pulse/
    SKILL.md
    reference.md
```

## Skills included

| Skill | Purpose |
| --- | --- |
| `leader-360` | Monday-ready weekly operating brief with dashboard, leadership update, risks, and first moves |
| `leader-concierge` | Front door that routes a leadership goal to the right Chief-of-staff skill |
| `executive-drafts` | Executive-ready emails, Teams updates, stakeholder notes, and compact data-backed summaries |
| `leadership-pack` | Board, steering committee, QBR, and leadership pack structure with governance tables |
| `team-pulse` | Weekly visible-work digest across direct reports with blocker and low-visibility flags |

## Packaging rule

If uploading as a single file, upload the ZIP built from the contents of this folder. The ZIP must open directly to `manifest.json`, `color.png`, `outline.png`, and `skills/`.

Do not zip each skill separately. Cowork must be able to see expanded folders under `skills/<skill-name>/SKILL.md`.

## Safety posture

All skills are review-first. They may draft messages, packs, dashboards, and recommendations, but they must not send, post, publish, share, create tasks, update systems, or change calendars without explicit user confirmation.
