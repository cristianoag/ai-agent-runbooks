# Fabric IQ Finance Analytics reference

## KPI dictionary by sub-report

### Margin
| KPI | Definition | Typical source field |
| --- | --- | --- |
| Gross margin % | (Revenue − COGS) ÷ Revenue | `GrossMargin%` measure |
| Margin by product/segment | Margin split by dimension if modeled | Product/segment dimension |

### Spend
| KPI | Definition | Typical source field |
| --- | --- | --- |
| Spend vs. budget | Actual spend ÷ budgeted spend | `Actual`, `Budget` measures |
| Spend by category | Opex breakdown if modeled | Cost-category dimension |

### Forecast variance
| KPI | Definition | Typical source field |
| --- | --- | --- |
| Forecast variance | (Actual − Forecast) ÷ Forecast | `Actual`, `Forecast` measures |

## Materiality thresholds (defaults)

| Flag | Band |
| --- | --- |
| 🟢 Green | Variance within ±5% |
| 🟡 Amber | Variance between ±5% and ±15% |
| 🔴 Red | Variance beyond ±15%, or spend exceeds budget with no approved exception |

Override with cohort-specific thresholds if configured in the report.

## Narrative style

- Use favorable/unfavorable language for variance, not just "up/down" — finance leaders read
  variance direction relative to plan, not absolute movement.
- Flag any budget overrun distinctly from a forecast miss — they imply different actions.

## Persona decision lens

| Persona | Prioritize |
| --- | --- |
| CFO / Finance leader | Enterprise variance, margin and cash risk, decisions and trade-offs |
| FP&A | Forecast accuracy, material drivers, scenario and planning implications |
| Controller | Reconciliation, exceptions, accounting consistency, data quality |
| Cost-center owner | Controllable spend, budget actions, timing and accountability |

Do not evaluate or rank named employees. Analyze cost centers, accounts, regions, categories, and
financial outcomes.
