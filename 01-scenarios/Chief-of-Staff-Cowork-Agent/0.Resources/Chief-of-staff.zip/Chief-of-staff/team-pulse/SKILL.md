---
name: team-pulse
description: |
  Builds a weekly pulse digest for a people manager's direct reports from visible work signals:
  shipped work, meetings led, collaborators, blockers, and low-visibility gaps. Use when the user
  says "team pulse", "what is my team up to", "weekly digest of my reports", "how is my team doing
  this week", or "give me a read on my reports". It is not for ranking, rating, performance
  evaluation, wellbeing monitoring, or working-hours surveillance.
metadata:
  owner: Productivity Squad
  version: 1.0.0
  classification: Public
  verified: false
  category: People
  suite: Chief-of-staff
  reference: reference.md
  m365Apps: Outlook, Teams, Calendar, People
  benefits:
    - "Save Time|3|hrs/month"
    - "Increase Visibility|100|% direct reports surfaced"
    - "Reduce Risk|Earlier blocker visibility"
  evals:
    - "Report coverage|Recall|Every resolved direct report appears in the digest"
    - "Factual traceability|Precision|Every summary statement traces to a visible artifact"
    - "No surveillance|Compliance|No ratings, rankings, wellbeing inference, or working-hours analysis"
---

# Team pulse

## At a glance

| Field | Detail |
| --- | --- |
| Primary job | Weekly visible-work digest across direct reports |
| Default window | Last seven days in the user's local timezone |
| Best output | Per-person summary + watch list + light-touch check-in prompts |
| Safety posture | Awareness only, never evaluation |
| Reference file | `reference.md` |

## What this skill does

Team Pulse summarizes visible work signals for a people manager's direct reports from the manager's
own email, calendar, and chat context. For each person, it summarizes what they shipped or drove,
who they collaborated with, and blockers they raised. It also flags low-visibility gaps as prompts
for light-touch check-ins.

Low visibility is a signal-coverage gap, not a judgment about the person.

## When to use

Use when the user asks:

- "team pulse"
- "what is my team up to?"
- "weekly digest of my reports"
- "how is my team doing this week?"
- "give me a read on my reports"

Do not use for a single person's 1:1 prep, performance evaluation, rankings, ratings, sentiment
analysis, wellbeing monitoring, or working-hours analysis.

## Inputs

| Input | Source | Use |
| --- | --- | --- |
| Direct reports | People profile / org data | Resolve team roster; do not guess |
| Email signals | Outlook | Updates, decisions, deliverables, blockers involving the manager |
| Calendar signals | Outlook Calendar | Meetings led, reviews, planning sessions, stakeholder moments |
| Chat signals | Teams | Blockers, asks, decisions, visible progress |
| User-provided roster | User | Use only if direct reports cannot be resolved |

## Workflow

1. **Resolve the team.** Get the user's direct reports from org data. If unavailable, ask for a
   named roster.
2. **Set the window.** Default to the last seven days in the user's local timezone unless the user
   specifies a different period.
3. **Gather per-person evidence.** Look for visible artifacts: updates, meetings led, documents
   shared, decisions, collaborators, and blockers raised.
4. **Summarize each person.** Write two to four sentences per person. Include only traceable facts.
5. **Build the watch list.** Flag low visibility or open blockers, with suggested light-touch
   check-ins.
6. **Stop at review.** Return a read-only digest. Do not send, share, file, evaluate, or score.

## Output format

```markdown
# Team Pulse - <date range>

## Executive snapshot
<short summary of team-level themes without ranking or evaluation>

## Team digest
| Person | Visible work | Collaborators / forums | Blockers or asks | Visibility |
| --- | --- | --- | --- | --- |
| <name> | <summary> | <names/forums> | <blocker/none seen> | <Normal/Low visibility> |

## Watch list
- <Name> - <signal observed or missing> -> <suggested check-in>

## Source gaps
- <missing source or limitation>

## Requires user confirmation before sharing
Yes
```

## Style standard

- Describe observable work, not personal qualities.
- Use "low visibility" for missing signal; never infer inactivity.
- Keep each person balanced and factual.
- Avoid comparison language.
- Suggest manager check-ins without implying fault.

## Guardrails

- **No surveillance.** Do not monitor or infer wellbeing, stress, sentiment, morale, mood,
  engagement, working hours, after-hours activity, or focus-time patterns.
- **No rating or ranking.** Do not score, rank, compare, or evaluate any report.
- **No fabrication.** Use only visible artifacts. Missing data stays visible.
- **Private-data safe.** Summarize at business-need level and avoid unnecessary sensitive details.
- **Review-only by default.** Do not send, share, file, or notify anyone without explicit
  confirmation.

## Reference

Use `reference.md` for signal categories, watch-list rules, phrasing standards, and anti-patterns.
