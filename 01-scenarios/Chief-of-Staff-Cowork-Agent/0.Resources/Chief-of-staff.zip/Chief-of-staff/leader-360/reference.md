# Leader 360 reference

## Operating model

Leader 360 is the package's Monday operating brief. It combines five views in one polished output:

| View | Purpose |
| --- | --- |
| Executive snapshot | The top-level "what matters this week" readout |
| Dashboard | Week-ahead calendar pressure, open items, highlights, and focus themes |
| Leadership update | Outcome-first summary for manager or skip-level consumption |
| Risk lens | Watchlist, active mitigations, and escalation candidates |
| Monday first moves | The first three to five actions that create momentum |

## RAG model

| RAG | Meaning | Typical signals |
| --- | --- | --- |
| Green | Week is under control | Clear priorities, manageable open items, no material unresolved decision |
| Amber | Needs active management | Multiple pressure points, moderate risk, unclear owner, or dependency risk |
| Red | Needs intervention | Material blocker, overdue critical item, high-impact risk, or decision stalled |

## Dashboard layout

Use a clean executive layout:

1. Hero bar: week, overall RAG, one-line summary
2. KPI cards: meetings, decisions, open items, overdue items, risks, highlights
3. Week at a glance: days, pressure, key moments
4. Focus themes: three to five themes with rationale
5. Open-items ledger: overdue, due this week, waiting, no-date
6. Highlights: outcomes, decisions, artifacts, risks reduced
7. Risk lens: watchlist, active mitigation, escalation candidate
8. Monday first moves
9. Source gaps and confidence notes

## Risk thresholds

| Level | Description | Handling |
| --- | --- | --- |
| Watchlist | Could slip but owner and mitigation are plausible | Keep in dashboard |
| Active mitigation | Current issue with mitigation underway | Include in leadership update risks |
| Escalation candidate | Needs decision, resource, air cover, or cross-team unblock | Draft formal risk callout |

## Leadership update style

Use outcome-first phrasing:

| Weak | Better |
| --- | --- |
| "Worked on the workshop plan." | "Workshop readiness improved after agenda, owners, and success criteria were aligned." |
| "Discussed blockers with the team." | "Delivery risk reduced after blockers were assigned to owners with target dates." |
| "Waiting for input." | "Decision remains blocked until <owner> confirms <input> by <date>." |

## Sharing gate

Default state: not sent.

Before any sharing or action, show exact recipients, exact content, and a private-data warning if
the message uses calendar, mail, chat, file, or meeting content.
