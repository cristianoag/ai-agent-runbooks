# Leadership Pack reference

## Pack archetypes

| Pack type | Best format | Core sections |
| --- | --- | --- |
| Board update | Word or PowerPoint | Recommendation, context, evidence, options, decision |
| Steering committee pack | PowerPoint | Status, risks, decisions, actions, dependencies |
| QBR pack | PowerPoint | Outcomes, metrics, narrative, risks, next-quarter focus |
| Operating review | Word or PowerPoint | KPI snapshot, exceptions, decisions, owner actions |
| Executive readout | Word | Executive summary, what changed, implications, asks |

## Narrative spine

Every pack should answer:

1. Why are we here?
2. What changed?
3. What does leadership need to know?
4. What decision or support is needed?
5. What happens next?

## Governance tables

### Decision log

| Decision | Owner | Needed by | Evidence | Status |
| --- | --- | --- | --- | --- |

### Risk table

| Risk | Impact | Probability | Owner | Mitigation | Escalation needed |
| --- | --- | --- | --- | --- | --- |

### Action register

| Action | Owner | Due | Status | Source |
| --- | --- | --- | --- | --- |

### Metric snapshot

| Metric | Current | Change | Target / Threshold | Source |
| --- | --- | --- | --- | --- |

## Visual standard

- One message per slide or section.
- Use tables for governance and accountability.
- Use RAG labels with text reasons.
- Prefer source-backed short summaries over dense excerpts.
- Place decisions and asks where leadership can find them quickly.
- Put source gaps in their own section.

## Sharing gate

Default state: review-ready, not distributed.

Before distribution, show recipients, exact content or artifact summary, attachments/links, and a
private-data warning if the pack includes calendar, mail, Teams, file, or meeting-derived details.
