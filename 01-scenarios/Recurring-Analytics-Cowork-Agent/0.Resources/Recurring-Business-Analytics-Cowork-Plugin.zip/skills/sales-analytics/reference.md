# Fabric IQ Sales Analytics reference

## KPI dictionary by sub-report

### Revenue
| KPI | Definition | Typical source field |
| --- | --- | --- |
| Recognized/booked revenue | Total revenue closed or recognized in period | `Revenue`, `Bookings` measure on the model |
| Revenue by segment | Revenue split by product/region if modeled | Segment/region dimension |

### Pipeline
| KPI | Definition | Typical source field |
| --- | --- | --- |
| Pipeline value | Sum of open opportunity value | `PipelineValue` measure |
| Pipeline coverage ratio | Pipeline value ÷ remaining quota | Derived only if both are modeled; otherwise data gap |
| Stage movement | Count of opportunities advancing/slipping stage | Stage-history table, if modeled |

### Attainment
| KPI | Definition | Typical source field |
| --- | --- | --- |
| Quota attainment % | Actual revenue ÷ quota/target | `Attainment%` measure or Revenue/Quota |

## Materiality thresholds (defaults)

| Flag | Band |
| --- | --- |
| 🟢 Green | Change within ±5% of prior period |
| 🟡 Amber | Change between ±5% and ±15% |
| 🔴 Red | Change beyond ±15%, or attainment falls below 80% of quota pace |

Override with cohort-specific thresholds if configured in the report.

## Narrative style

- Lead with attainment risk if any region is materially behind pace — that's usually the most
  actionable signal for a sales leader.
- Use "closed-won," "slipped," "at risk" language consistent with the CRM/report's own stage
  names — don't invent generic terms if the report uses specific ones.
