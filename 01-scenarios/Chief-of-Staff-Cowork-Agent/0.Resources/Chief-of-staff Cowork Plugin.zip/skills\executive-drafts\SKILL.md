---
name: executive-drafts
description: |
  Drafts executive-ready emails, Teams updates, stakeholder notes, delegation messages, and
  leadership updates from recent Microsoft 365 context and data sources. Use when the user asks to
  "draft the update", "write the stakeholder email", "send a summary with a table", "prepare the
  weekly leadership note", or "turn this report into an email". Produces review-ready text with a
  compact data table when useful. Never sends, posts, or notifies anyone without explicit user
  confirmation.
metadata:
  owner: Productivity Squad
  version: 1.0.0
  classification: Public
  verified: false
  category: Executive Communications
  suite: Chief-of-staff
  reference: reference.md
  m365Apps: Outlook, Teams, Calendar, OneDrive, SharePoint, Excel, Power BI, Word
  benefits:
    - "Save Time|3|hrs/month"
    - "Improve Quality|Clearer executive updates"
    - "Increase Traceability|Source-backed table entries"
  evals:
    - "Executive-ready|Structure check|Draft opens with the point and ends with a clear ask or next step"
    - "Table usefulness|Precision|Table clarifies the message and avoids report dumping"
    - "Source grounding|Precision|Every metric, risk, owner, and date traces to evidence"
---

# Executive Drafts

## At a glance

| Field | Detail |
| --- | --- |
| Primary job | Draft one executive communication |
| Best output | Ready-to-review message + compact table + source basis |
| Channels | Email, Teams, Word, stakeholder note |
| Safety posture | Preview exact content before any send or post |
| Reference file | `reference.md` |

## What this skill does

Turns fragmented executive context into a concise communication. It can draft an email, Teams
update, stakeholder note, delegation message, or weekly leadership summary, and it adds a compact
data table when metrics, owners, dates, risks, decisions, or actions make the message clearer.

## When to use

Use when the user asks to draft, summarize, or communicate a focused executive update. Use a sibling
skill instead when the user needs a full board or leadership pack, a weekly operating brief, a team
pulse digest, or routing help.

## Inputs

| Input | Source | Use |
| --- | --- | --- |
| Communication goal | User request | Audience, channel, purpose, action, deadline |
| Recent context | Outlook, Teams, Calendar | Decisions, commitments, asks, meeting outcomes |
| Source files | OneDrive, SharePoint | Reports, decks, docs, trackers, source links |
| Data sources | Excel, CSV, Power BI exports, SharePoint lists | Metrics, owners, risks, dates, changes |
| Recipient context | User request, Outlook, Teams | Role and relationship context, not personal evaluation |

## Workflow

1. **Clarify the job.** Determine audience, channel, purpose, tone, deadline, and whether a table is
   needed.
2. **Collect source evidence.** Read the minimum relevant sources and keep source names or links.
3. **Extract the message spine.** Identify the executive point: status, decision, risk,
   recommendation, request, or delegation.
4. **Build the table only if useful.** Use compact columns and avoid copying a whole report.
5. **Draft the communication.** Lead with the outcome or ask, add interpretation, and close with
   the decision or next step.
6. **Prepare the send gate.** Present exact recipients, exact content, and any private-data warning
   before any outbound action.

## Output format

```markdown
## Draft communication - <audience or topic>

**Audience:** <recipient/group>
**Channel:** <email/Teams/Word/other>
**Purpose:** <decision/update/request/delegation>
**Tone:** <concise/executive/factual/warm/etc.>

### Executive point
<one or two sentences: what the reader needs to know or do>

### Draft
<ready-to-review text>

### Data table
| Metric / Topic | Current | Change | Owner | Due | Action Needed |
| --- | --- | --- | --- | --- | --- |
| <item> | <value> | <delta> | <owner> | <date> | <action> |

### Source basis
- <file/report/thread/meeting/link>

### Requires user confirmation before sending
Yes
```

## Style standard

- Lead with the decision, risk, outcome, or ask.
- Keep the opening short enough for a busy executive to act on.
- Use tables for clarity, not decoration.
- Mark missing metrics as `Unavailable`; never invent them.
- Use source-backed summaries rather than long copied excerpts.

## Guardrails

- **Review-only by default.** Do not send, post, share, file, or notify anyone without explicit
  confirmation.
- **Preview before sending.** Show recipients, exact content, and private-data warnings before any
  outbound action.
- **No fabrication.** Every metric, risk, owner, date, decision, and claim must trace to evidence.
- **No personal evaluation.** Do not rate, rank, profile, or infer sentiment about people.
- **Private-data safe.** Avoid private schedule, travel, personal, or sensitive business details
  unless explicitly requested and confirmed.

## Reference

Use `reference.md` for message patterns, table design, channel guidance, and send-gate rules.
