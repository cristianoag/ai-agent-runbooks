# Fabric IQ Business Analytics Concierge reference

## Function-keyword matching table

| Keyword signals in the ask | Route to |
| --- | --- |
| revenue, pipeline, bookings, quota, attainment, deals, forecast (sales) | `sales-analytics` |
| margin, spend, budget, opex, forecast variance, cost center | `finance-analytics` |
| sales (retail), inventory, sell-through, stock, SKU, store | `retail-analytics` |
| throughput, yield, quality, defect rate, OEE, line, plant | `manufacturing-analytics` |
| cases, tickets, backlog, SLA, escalation, queue | `service-analytics` |

## Disambiguation examples

| Ask | Handling |
| --- | --- |
| "Run the weekly business performance review for North America" | No function keyword — check which skills are configured for this tenant; if only one is configured, route directly with a one-line confirmation; if several, ask which function. |
| "Run my sales review for EMEA" | Explicit keyword ("sales") — route directly to `sales-analytics` with region EMEA. |
| "How did we do this week?" | Fully generic — ask which function(s) to include, or offer to run all configured reviews for the region if the user confirms. |

## Handoff parameter contract

When calling a downstream skill, pass exactly:

- `region_or_segment` (string, e.g., "North America")
- `period` (string, defaults to "last full week")

Downstream skills own everything else (report URL, KPI list, thresholds).
