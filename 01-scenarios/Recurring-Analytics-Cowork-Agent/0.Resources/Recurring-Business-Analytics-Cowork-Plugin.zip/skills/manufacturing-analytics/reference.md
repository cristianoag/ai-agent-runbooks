# Fabric IQ Manufacturing Analytics reference

## KPI dictionary by sub-report

### Throughput
| KPI | Definition | Typical source field |
| --- | --- | --- |
| Units produced | Total units completed in period | `UnitsProduced` measure |
| OEE (Overall Equipment Effectiveness) | Availability × Performance × Quality | `OEE%` measure, if modeled |
| Line utilization | Actual run time ÷ available time | `Utilization%` measure |

### Quality
| KPI | Definition | Typical source field |
| --- | --- | --- |
| First-pass yield | Units passing quality on first attempt ÷ total units | `FPY%` measure |
| Defect rate | Defective units ÷ total units | `DefectRate%` measure |
| Quality escapes | Defects found post-shipment | `QualityEscapes` measure, if modeled |

## Materiality thresholds (defaults)

| Flag | Band |
| --- | --- |
| 🟢 Green | Change within ±5% |
| 🟡 Amber | Change between ±5% and ±15% |
| 🔴 Red | Change beyond ±15%, or any quality/safety limit breach regardless of magnitude |

Override with cohort-specific thresholds if configured in the report.

## Narrative style

- Treat a quality escape as always material — surface it in the executive summary even if the
  raw defect-rate % change looks small.
- Distinguish planned downtime from unplanned stoppages when explaining a throughput drop, if the
  report's own dimensions support that distinction.

## Persona decision lens

| Persona | Prioritize |
| --- | --- |
| Operations VP | Network capacity, systemic constraints, cross-plant actions |
| Plant manager | Plant/line performance, recovery plan, resource decisions |
| Quality leader | Yield, defects, release status, quality escapes and traceability |
| Line supervisor | Shift, line, material-lot and batch exceptions requiring containment |

Do not evaluate or rank named employees. Use plant, line, shift, batch, product and material
dimensions.
