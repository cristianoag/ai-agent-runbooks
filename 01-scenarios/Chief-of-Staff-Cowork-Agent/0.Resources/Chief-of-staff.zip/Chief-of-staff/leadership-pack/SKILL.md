---
name: leadership-pack
description: |
  Builds leadership-ready Word briefs, PowerPoint pack outlines, board memos, steering committee
  packs, QBR updates, and operating-review narratives from meetings, email threads, Teams context,
  documents, reports, decisions, risks, open actions, and source data. Use when the user asks to
  "build the leadership pack", "make a board update", "create a deck", "prepare the exec readout",
  "turn this into a Word brief", or "assemble the steering committee pack". Produces a sourced,
  review-ready pack; never publishes or distributes without explicit user confirmation.
metadata:
  owner: Productivity Squad
  version: 1.0.0
  classification: Public
  verified: false
  category: Executive Communications
  suite: Chief-of-staff
  reference: reference.md
  m365Apps: Word, PowerPoint, Outlook, Teams, Calendar, OneDrive, SharePoint, Excel, Power BI, Planner
  benefits:
    - "Save Time|4|hrs/pack"
    - "Improve Quality|More decision-ready structure"
    - "Reduce Risk|Visible source gaps"
  evals:
    - "Narrative spine|Structure check|Pack opens with objective, recommendation or executive narrative, then evidence and decisions"
    - "Governance coverage|Coverage|Includes decision log, risk table, action register, and metric snapshot when applicable"
    - "Source grounding|Precision|Claims, metrics, risks, and asks trace to evidence"
---

# Leadership Pack

## At a glance

| Field | Detail |
| --- | --- |
| Primary job | Build a sourced board, leadership, QBR, or steering pack |
| Best output | Executive narrative + artifact structure + governance tables |
| Formats | Word-ready brief, PowerPoint-ready outline, markdown source pack |
| Safety posture | Review-only until sharing is confirmed |
| Reference file | `reference.md` |

## What this skill does

Builds the recurring executive artifact a Chief of Staff or leader often needs: a concise Word
brief, PowerPoint pack outline, board memo, steering committee pack, QBR update, or operating-review
narrative. It turns scattered context into a source-backed pack with a narrative spine, decision
log, risk table, action register, metric snapshot, and source list.

## When to use

Use when the user asks for a full leadership artifact, not just a single message. Use a sibling
skill instead when the user needs one communication, a weekly operating brief, a team pulse digest,
or routing help.

## Inputs

| Input | Source | Use |
| --- | --- | --- |
| Pack objective | User request | Audience, meeting, decision, artifact type, deadline |
| Meeting history | Calendar, Teams recaps, transcripts | Decisions, unresolved questions, action history |
| Communications | Outlook, Teams | Stakeholder asks, escalations, commitments, blockers |
| Source files | OneDrive, SharePoint | Existing decks, docs, trackers, reports |
| Data snapshots | Excel, Power BI exports, SharePoint lists | Metrics, risks, owners, due dates, trends |
| Action records | To Do, Planner, lists | Open actions, closed actions, stale items |

## Workflow

1. **Clarify the pack job.** Determine audience, format, source window, decision to support, length,
   and expected artifact type.
2. **Inventory source material.** List files, meetings, threads, reports, trackers, and data
   snapshots used. Flag unavailable, stale, conflicting, or thin sources.
3. **Build the narrative spine.** State context, recommendation or update, evidence, decisions
   needed, risks, asks, and next actions.
4. **Choose the structure.** For PowerPoint, produce slide titles, purpose, key points, and visuals.
   For Word, produce headings, executive summary, tables, and appendices.
5. **Add governance tables.** Include decision log, risk table, action register, and metric snapshot
   when useful.
6. **Return the review pack.** Do not publish, distribute, email, share, or file unless the user
   explicitly confirms.

## Output format

```markdown
## Leadership pack - <audience> - <date>

**Format:** <Word/PPT/Markdown source pack>
**Objective:** <decision/update/alignment>
**Source window:** <dates>
**Overall status:** <Green/Amber/Red> - <reason>

### Executive narrative
<short summary that opens with the decision, recommendation, or leadership point>

### Proposed artifact structure
| Section / Slide | Purpose | Key content | Suggested visual | Source |
| --- | --- | --- | --- | --- |
| <section> | <purpose> | <content> | <visual> | <link/source> |

### Metric snapshot
| Metric | Current | Change | Target / Threshold | Source |
| --- | --- | --- | --- | --- |
| <metric> | <value> | <delta> | <target> | <source> |

### Decision log
| Decision | Owner | Needed by | Evidence | Status |
| --- | --- | --- | --- | --- |
| <decision> | <owner> | <date> | <link/source> | <status> |

### Risks and actions
| Risk / Action | Owner | Due | Status | Mitigation / Next step |
| --- | --- | --- | --- | --- |
| <item> | <owner> | <date> | <status> | <next step> |

### Source gaps
- <missing/stale/conflicting source>

### Requires user confirmation before sharing
Yes
```

## Style standard

- Open with the decision, recommendation, or leadership point.
- Keep one idea per slide or section.
- Use governance tables to clarify ownership and decisions.
- Use RAG labels only with text reasons.
- Keep source gaps visible.

## Guardrails

- **Review-only by default.** Do not publish, distribute, email, share, file, or notify anyone
  without explicit confirmation.
- **No unsupported claims.** Do not create leadership-facing claims without source evidence.
- **Private-data safe.** Avoid private schedule, travel, personal, or sensitive business details
  unless explicitly requested and confirmed.
- **No personal evaluation.** Do not rate, rank, profile, or infer sentiment about people.
- **Formatting and workflow only.** Organize and draft; do not make legal, medical, financial, HR,
  or compliance decisions.

## Reference

Use `reference.md` for pack archetypes, governance tables, narrative patterns, visuals, and sharing
rules.
