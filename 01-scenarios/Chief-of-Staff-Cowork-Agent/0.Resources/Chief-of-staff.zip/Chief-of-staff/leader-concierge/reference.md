# Leader Concierge reference

## Package directory

| User goal | Skill | Trigger phrase | Schedule-worthy |
| --- | --- | --- | --- |
| Weekly operating brief, Monday reset, executive dashboard | `leader-360` | "Leader 360" | Yes - Monday 8 AM |
| One executive email, Teams update, stakeholder note, or short data-backed message | `executive-drafts` | "draft the update" | On demand |
| Full board, steering committee, QBR, or leadership pack | `leadership-pack` | "build the leadership pack" | On demand |
| Weekly digest of direct reports' visible work and blockers | `team-pulse` | "team pulse" | On demand |
| Routing help across the package | `leader-concierge` | "help me choose" | On demand |

## Routing tests

| If the user says | Route to |
| --- | --- |
| "What should leadership know this week?" | `leader-360` |
| "Create a Monday dashboard" | `leader-360` |
| "Write the stakeholder email" | `executive-drafts` |
| "Turn this report into a note" | `executive-drafts` |
| "Build the board pack" | `leadership-pack` |
| "Create a QBR deck outline" | `leadership-pack` |
| "What is my team up to?" | `team-pulse` |
| "Which skill should I use?" | `leader-concierge` |

## Ambiguity rules

- If the request says "update" and names recipients or a channel, route to executive communications.
- If the request says "pack", "deck", "board", "QBR", or "steering committee", route to board pack builder.
- If the request spans the week and asks for readiness, route to Leader 360.
- If the request asks about direct reports or team activity, route to Team Pulse.
- If two skills fit, pick the narrower artifact first and mention the alternative.

## No-match response

Use this wording:

```markdown
I do not have a Chief-of-staff skill for <goal> yet. This package currently covers Leader 360,
executive communications, leadership packs, team pulse, and routing help.
```

## Schedule guidance

Leader 360 is the only default recurring workflow in this package: Monday at 8:00 AM local time.
Do not create a schedule unless the user explicitly confirms the exact prompt and cadence.

## Visual standard

All package skills should use:

- A short "At a glance" table
- Clear inputs table
- Numbered workflow
- Markdown output template
- Explicit guardrails
- Source gaps where evidence is missing
