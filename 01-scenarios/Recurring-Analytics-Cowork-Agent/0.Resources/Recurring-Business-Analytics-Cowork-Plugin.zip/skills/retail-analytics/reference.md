# Fabric IQ Retail Analytics reference

## KPI dictionary by sub-report

### Sales
| KPI | Definition | Typical source field |
| --- | --- | --- |
| Sales (store/e-commerce) | Total sales value in period | `Sales` measure |
| Sales by category/store | Sales split by dimension if modeled | Category/store dimension |

### Inventory
| KPI | Definition | Typical source field |
| --- | --- | --- |
| Inventory position | On-hand units/value | `InventoryOnHand` measure |
| Stockout flag | SKU/store below safety stock | Derived if safety-stock threshold modeled |
| Overstock flag | SKU/store above target weeks-of-supply | Derived if target modeled |

### Sell-through
| KPI | Definition | Typical source field |
| --- | --- | --- |
| Sell-through rate | Units sold ÷ units received (or ÷ average inventory) | `SellThrough%` measure |

## Materiality thresholds (defaults)

| Flag | Band |
| --- | --- |
| 🟢 Green | Change within ±5% |
| 🟡 Amber | Change between ±5% and ±15% |
| 🔴 Red | Change beyond ±15%, any stockout, or sustained overstock beyond target weeks-of-supply |

Override with cohort-specific thresholds if configured in the report.

## Narrative style

- Always call out stockouts explicitly even if the overall sales trend is green — a stockout is
  a distinct, immediately actionable risk.
- State sell-through relative to plan/target, not just as a raw percentage.

## Persona decision lens

| Persona | Prioritize |
| --- | --- |
| Retail GM | Sales trend, commercial opportunity, network-level actions |
| Merchandiser | Category, product and promotion movement |
| Inventory planner | Stockout, overstock, replenishment and weeks-of-supply risk |
| Store / distributor operations | Local exceptions, availability and immediate actions |

Do not evaluate or rank named store employees. Use product, category, store, distributor, cluster,
and region dimensions.
