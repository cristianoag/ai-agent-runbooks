# Business Function Recurring Analytics

A coordinated skills package for the **Fabric IQ plugin Factory implementation scenario**:
recurring, function-specific business performance reviews grounded entirely in a single
customer-supplied **Power BI Semantic Model or Fabric dataset URL**. Any customer with a
published Power BI report or Fabric dataset qualifies for this Factory pattern — no
per-customer connector or ERP integration work is required.

A customer's implementation exposes prompts like:

> "Run the Weekly Business Performance Review for North America."

Fabric IQ resolves the request to the right functional skill below, retrieves the grounded
Power BI report configured for that function/region, and returns period-over-period values,
variance, and plain-language trend explanations.

## Skills

| Skill | Business function | Sub-reports bundled into this one skill |
| --- | --- | --- |
| `fabriciq-business-analytics-concierge` | Routing | Front door that resolves function + region and hands off to the right function skill |
| `sales-analytics` | Sales | Revenue, pipeline, attainment |
| `finance-analytics` | Finance | Margin, spend, forecast variance |
| `retail-analytics` | Retail | Sales, inventory, sell-through |
| `manufacturing-analytics` | Manufacturing | Throughput, quality measures |
| `service-analytics` | Service | Cases, backlog, SLA measures |

Each function skill is intentionally **one skill per business function**, not one skill per
sub-report. `sales-analytics`, for example, produces revenue, pipeline, and
attainment as three clearly labeled sections of a single review — not three separate skills to
invoke.

## Prerequisites (per customer, per function)

Every skill in this package is grounded in a Power BI report, Fabric semantic model, or Excel
Online workbook that Cowork uses to generate recurring analytics.

1. The user must have access to the data source — a Power BI report, Fabric dataset, or Excel
   Online URL — against which they want Cowork to generate recurring analytics.
2. Users can schedule these reports in Cowork for a daily, weekly, quarterly, or other targeted
   cadence as required.
3. Analytics output is based solely on the connected data source, such as Power BI reports,
   Fabric datasets, or Excel Online data.
4. Users without appropriate access to the underlying report will not be able to fetch or view
   the analytics.
5. If the data is not available in a Power BI, Fabric (dataset or semantic model), or Excel
   Online format, and instead relies on third-party services such as Tableau, Qlik, or Databricks,
   consider other options such as Copilot Studio custom agents or Azure AI Foundry solutions.

**How the URL is provided:** each skill asks the user directly in Cowork when invoked:
*"Please provide your Power BI, Fabric dataset, or Excel Online URL for Cowork to generate
recurring business analytics."* Whatever URL is supplied is used for that session's run; no URL
is stored permanently in the skill file. See each skill's Report URL Instructions section for
details.

## Folder standard

Each skill folder contains:

- `SKILL.md` — the executable skill definition: configurations and pre-requisites, workflow,
  output format, and guardrails.
- `reference.md` — the KPI dictionary, materiality thresholds, and narrative style for that
  business function.

## Package standards

- **Grounded in Power BI, Fabric, or Excel Online.** Each skill is grounded in a Power BI report,
  Fabric semantic model, or Excel Online workbook that Cowork uses to generate recurring
  analytics. The skill reads named measures already defined in the source and computes
  period-over-period comparisons on top of them — it does not recompute business logic the
  model already defines.
- **Grounded, not invented.** Every number and trend explanation traces back to the connected
  data source. If the source can't answer part of the ask, say so — never fabricate a figure.
- **Region and period aware.** Every skill accepts a region/segment scope (e.g., "North
  America") and a review period (default: last full week) as run-time parameters.
- **Review-ready by default.** Outputs are drafts for the requesting leader to read or share;
  no email, Teams post, or external distribution happens without explicit confirmation.
- **Consistent structure.** At a glance, configurations and pre-requisites, inputs, workflow,
  output template, style standard, guardrails, and reference — matching the Chief-of-Staff
  skill package convention.

## Recommended cadence

Default cadence is **weekly** ("Weekly Business Performance Review"), configurable to daily,
monthly, quarterly, or any other targeted cadence for functions with tighter or looser
tolerances (e.g., Service SLA breaches, Manufacturing quality escapes). All skills also support
on-demand, ad hoc runs ("run my sales review for EMEA right now").

## Related patterns

- `powerbi-fabric-variance-analysis` and `recurring-analytics-factory-pattern` (sibling skills in
  the parent `skills` folder) — this package specializes that general Factory pattern into one
  distinct, named skill per business function.
- `recurring_analytics_skills.md` — the broader multi-output recurring analytics pack (HTML
  dashboard, email digest, PPT deck, report writer) that these review skills can feed into as a
  single upstream "analyze + explain" step.

## Package location

`skills\business_function_recurring analytics\` (folder name intentionally matches the package
name given by the customer/admin standing up this Factory implementation).
