# Team Pulse reference

## Signal categories

| Signal | Include | Do not include |
| --- | --- | --- |
| Shipped work | Completed deliverables, shared artifacts, closed actions | Unverified claims or inferred effort |
| Meetings led | Meetings organized, chaired, or visibly driven | Attendance as a proxy for productivity |
| Collaboration | People, groups, or forums connected to work | Relationship scoring or sentiment |
| Blockers | Explicitly raised risks, asks, or dependencies | Inferred stress, mood, or wellbeing |
| Low visibility | No visible artifacts in available sources | Inactivity, disengagement, or performance judgment |

## Watch-list rules

Add someone to the watch list only when:

- A blocker or dependency is explicitly visible.
- There is low visibility across available sources.
- A commitment appears overdue or unresolved.

Do not add someone because of message timing, after-hours work, calendar density, perceived tone, or
absence from meetings.

## Preferred phrasing

| Avoid | Use |
| --- | --- |
| "<Name> seems disengaged." | "Low visibility in available sources this week; consider a light-touch check-in." |
| "<Name> is underperforming." | "No completed deliverable was visible in the sources reviewed." |
| "<Name> is stressed." | "A blocker was raised around <topic>; follow-up may help unblock it." |
| "<Name> worked late." | Omit working-hours observations entirely. |

## Output balance

Each person should receive comparable structure:

1. Visible work or "no visible completed work found"
2. Key collaborators or forums
3. Blockers or asks
4. Visibility status

## Safety standard

Team Pulse is for manager awareness only. It is not a performance review, ranking, wellbeing
assessment, engagement score, productivity score, or surveillance report.
